<h1>Hey {{$name}}!</h1>
<p>Reference No: {{$reference_no}}</p>
<p>Your payroll is: {{$amount}} {{$general_setting->currency}}</p>
<p>Thank you</p>